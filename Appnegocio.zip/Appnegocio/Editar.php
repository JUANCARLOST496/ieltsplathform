<?php include 'inc/layout/header.php';?>

<div class="contenedor-barra">
    <div  class="contenedor barra">
          <a href="../Appnegocio/registradora.php" class="btn volver">volver</a>
          <h1>Editar contacto</h1>
        </div>
     </div>

     <div class="bg-amarillo contenedor sombra">
         <form id="contacto" action="#">
           <div class="anex">Editar contacto</span></div>
           
           <?php include 'inc/layout/formulario.php';?>
         </form>
        
</div>


<?php include 'inc/layout/footer.php';?>